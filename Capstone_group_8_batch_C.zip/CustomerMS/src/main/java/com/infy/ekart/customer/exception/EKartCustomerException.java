package com.infy.ekart.customer.exception;

public class EKartCustomerException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EKartCustomerException(String message) {
		super(message);
	}

}
