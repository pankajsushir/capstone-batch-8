package com.infy.ekart.cart.exception;

public class EKartCustomerCartException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EKartCustomerCartException(String message) {
		super(message);
	}

}
